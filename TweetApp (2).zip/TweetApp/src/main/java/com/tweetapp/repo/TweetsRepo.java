package com.tweetapp.repo;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.tweetapp.dto.TweetsDto;
import com.tweetapp.entities.TweetsEntity;
@Repository
public interface TweetsRepo extends MongoRepository<TweetsEntity, ObjectId> {

}
