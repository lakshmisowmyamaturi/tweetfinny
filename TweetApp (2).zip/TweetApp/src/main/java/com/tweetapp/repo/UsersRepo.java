package com.tweetapp.repo;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.entities.UsersEntity;

@Repository
public interface UsersRepo extends MongoRepository<UsersEntity, ObjectId> {

	@Query("select e from UsersEntity where e.login_id = :username ")
	UsersEntity findById(@Param(value = "username") String username);

}
