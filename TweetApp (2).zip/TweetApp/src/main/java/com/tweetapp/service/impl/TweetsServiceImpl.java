package com.tweetapp.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.TweetsDto;
import com.tweetapp.entities.TweetsEntity;
import com.tweetapp.repo.TweetsRepo;
import com.tweetapp.response.TweetResponse;
import com.tweetapp.service.TweetsService;

@Service
public class TweetsServiceImpl implements TweetsService {

	
	@Autowired
	TweetsRepo tweetsRepo;
	
	@Override
	public TweetResponse getAllTweets() {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		List<TweetsEntity> tweets = tweetsRepo.findAll();
		List<TweetsDto> tweetsDto = new ArrayList<>();
		tweets.forEach(entity->{
			TweetsDto tweet = new TweetsDto();
			tweet.setTweet(entity.getTweet());
			tweet.setTweet_id(entity.getTweet_id());
			tweet.setUser_tweet_id(entity.getUser_tweet_id());
			tweetsDto.add(tweet);
		});
		response.setTweetsDto(tweetsDto);
		return response;
	}

}
