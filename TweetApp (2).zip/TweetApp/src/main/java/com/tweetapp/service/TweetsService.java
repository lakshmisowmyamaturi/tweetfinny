package com.tweetapp.service;

import com.tweetapp.response.TweetResponse;

public interface TweetsService {

	TweetResponse getAllTweets();

}
