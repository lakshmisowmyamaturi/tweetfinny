package com.tweetapp.service;

import com.tweetapp.response.UserResponse;

public interface UsersService {

	UserResponse getAllUsers();

}
