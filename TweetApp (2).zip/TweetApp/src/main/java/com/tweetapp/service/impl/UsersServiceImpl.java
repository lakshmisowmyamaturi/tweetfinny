package com.tweetapp.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.UsersDto;
import com.tweetapp.entities.UsersEntity;
import com.tweetapp.repo.UsersRepo;
import com.tweetapp.response.UserResponse;
import com.tweetapp.service.UsersService;

@Service
public class UsersServiceImpl implements UsersService {
	
	@Autowired
	UsersRepo usersRepo;

	@Override
	public UserResponse getAllUsers() {
		// TODO Auto-generated method stub
		UserResponse response = new UserResponse();
		List<UsersEntity> users = usersRepo.findAll();
		List<UsersDto> usersDto = new ArrayList<>();
		users.forEach(entity->{
			UsersDto dto = new UsersDto();
			dto.setContact_number(entity.getContact_number());
			dto.setEmail_id(entity.getEmail_id());
			dto.setFirst_name(entity.getFirst_name());
			dto.setLast_name(entity.getLast_name());
			dto.setLogged_in(entity.getLogged_in());
			dto.setLogin_id(entity.getLogin_id());
			dto.setPassword(entity.getPassword());
			usersDto.add(dto);
		});
		response.setUsersDto(usersDto);
		return response;
	}

}
