package com.tweetapp.response;



import java.util.List;

import com.tweetapp.dto.UsersDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponse {

	private List<UsersDto> usersDto;
}
