package com.tweetapp.response;

import java.util.List;

import com.tweetapp.dto.TweetsDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TweetResponse {
 private List<TweetsDto> tweetsDto;
}
