//package com.tweetapp.controller;
//
//import java.util.Base64;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.RequestHeader;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.tweetapp.entities.UsersEntity;
//import com.tweetapp.repo.UsersRepo;
//
//import io.jsonwebtoken.JwtBuilder;
//import io.jsonwebtoken.Jwts;
//import io.jsonwebtoken.SignatureAlgorithm;
//
//
//
//
//@RestController
//public class AuthenticationController {
//	
//	static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);
//	
//	@Autowired
//	private UsersRepo usersRepository;
//	
//	@RequestMapping(value = "/authenticate", produces = { "application/json" }, method = RequestMethod.GET)
//	@CrossOrigin("http://localhost:3000")
//	public Map<String, String> loginPost( @RequestHeader(value = "Authorization", required = true) String authHeader) {
//		LOGGER.info("start inside authenticate method");
//		LOGGER.debug(authHeader);
//		System.err.println(authHeader);
//
//		Map<String, String> jwt = new HashMap<String, String>();
//
//		String username = getUser(authHeader);
//		UsersEntity user = usersRepository.findById(username);
//		String userId = user.getLogin_id();
//		String token = generateJwt(username);
//
//		jwt.put("token", token);
//		String role = SecurityContextHolder.getContext().getAuthentication().getAuthorities().toArray()[0].toString();
//		jwt.put("role", role);
//		jwt.put("username", user.getFirst_name());
//		jwt.put("userEmpId", user.getLogin_id());
//
//		LOGGER.info("end of authenticate method");
//		return jwt;
//	}
//	
//	private String getUser(String authHeader) {
//		String encodedCredentials = authHeader.split(" ")[1];
//
//		byte[] decodedCredentials = Base64.getDecoder().decode(encodedCredentials);
//		String user = new String(decodedCredentials).split(":")[0];
//		LOGGER.debug(user);
//		return user;
//	}
//
//	private String generateJwt(String user) {
//
//		JwtBuilder builder = Jwts.builder();
//		builder.setSubject(user);
//
//		builder.setIssuedAt(new Date());
//
//		builder.setExpiration(new Date((new Date()).getTime() + 1200000));
//		builder.signWith(SignatureAlgorithm.HS256, "secretkey");
//
//		String token = builder.compact();
//
//		return token;
//	}
//
//}
