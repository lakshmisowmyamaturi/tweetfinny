package com.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.response.TweetResponse;
import com.tweetapp.service.TweetsService;

@RestController
public class TweetController {

	@Autowired
	TweetsService tweetsService;

	@GetMapping(value = "/api/v1.0/tweets/all")
	public TweetResponse getAllTweets() {

		return tweetsService.getAllTweets();
	}
	
//	@GetMapping(value = "/api/v1.0/tweets/username")
//	public TweetResponse getAllTweetsUser(String userName) {
//		
//	}
}
