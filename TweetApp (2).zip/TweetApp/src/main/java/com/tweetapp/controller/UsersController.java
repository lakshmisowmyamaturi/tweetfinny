package com.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.response.UserResponse;
import com.tweetapp.service.UsersService;

@RestController
public class UsersController {

	@Autowired
	UsersService usersService;
	
	@RequestMapping(path = "/api/v1.0/tweets/users/all" , method = RequestMethod.GET)
	public UserResponse getAllUsers() {
		return usersService.getAllUsers();
	}
}
