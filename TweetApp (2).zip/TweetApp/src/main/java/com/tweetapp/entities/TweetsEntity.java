package com.tweetapp.entities;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection = "tweets")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TweetsEntity {
	
	@Id
	@JsonProperty("_id")
	private ObjectId _id;
	
	@JsonProperty("tweet")
	private String tweet;
	
	@JsonProperty("user_tweet_id")
	private String user_tweet_id;
	
	@JsonProperty("tweet_id")
	private String tweet_id;

}
