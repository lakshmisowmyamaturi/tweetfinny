package com.tweetapp.entities;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(collection = "users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsersEntity {

	@Id
	private ObjectId _id;

	private String login_id;

	private String first_name;

	private String last_name;

	private String email_id;

	private String password;

	private String contact_number;

	private Boolean logged_in;
}
