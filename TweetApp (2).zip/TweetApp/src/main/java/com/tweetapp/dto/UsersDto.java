package com.tweetapp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UsersDto {
	private String login_id;

	private String first_name;

	private String last_name;

	private String email_id;

	private String password;

	private String contact_number;

	private Boolean logged_in;
}
