package com.tweetapp.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRequest {

}
